//
//  AppDelegate.h
//  HelloWord
//
//  Created by 南京单聊李 on 2017/11/5.
//  Copyright © 2017年 南京单聊李. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

