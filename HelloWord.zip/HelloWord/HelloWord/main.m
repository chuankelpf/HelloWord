//
//  main.m
//  HelloWord
//
//  Created by 南京单聊李 on 2017/11/5.
//  Copyright © 2017年 南京单聊李. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
